from django.apps import AppConfig


class IntroappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'introapp'
